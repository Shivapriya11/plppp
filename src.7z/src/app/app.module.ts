import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EditComponent } from './review/edit/edit.component';
import { DeleteComponent } from './review/delete/delete.component';
import { FormsModule } from '@angular/forms';
import { ReviewService } from './review/service/review.service';
import { WelcomeComponent } from './review/welcome/welcome.component';
import { ReviewlistingpageComponent } from './review/reviewlistingpage/reviewlistingpage.component';
import { FrontendComponent } from './frontend/frontend.component';

@NgModule({
  declarations: [
    AppComponent,
    EditComponent,
    DeleteComponent,
    WelcomeComponent,
    ReviewlistingpageComponent,
    FrontendComponent,
  
  ],
  imports: [
    FormsModule ,
    HttpClientModule,
    BrowserModule,
    AppRoutingModule
  ],
  providers: [ReviewService],
  bootstrap: [AppComponent]
})
export class AppModule { }
