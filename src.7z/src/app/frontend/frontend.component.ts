import { Component, OnInit } from '@angular/core';
import { Review } from '../review/bean/review';
import { ActivatedRoute, Router } from '@angular/router';
import { ReviewService } from '../review/service/review.service';

@Component({
  selector: 'app-frontend',
  templateUrl: './frontend.component.html',
  styleUrls: ['./frontend.component.css']
})
export class FrontendComponent implements OnInit {
  review:Review[];
  reviewData:Review={"index":0,"id":0,"book":'',"rating":0,"headline":'',"customer":'',"reviewOn":'',"lastupdate":new Date('yyyy-mmm-dd')}
  constructor(private reviewService:ReviewService, 
  private router:Router,private route:ActivatedRoute){ }

  ngOnInit() {
    this.route.params.subscribe(
      (params)=>{this.reviewService.getReview(params['id']).subscribe((result)=>{this.reviewData=result;})}
      );
  }
  frontend(){
    console.log(this.reviewData.id);
this.reviewService.editReview(this.reviewData).subscribe((data)=>{this.router.navigate(['']);
}
    );}}

