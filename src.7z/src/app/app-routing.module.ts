import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EditComponent } from './review/edit/edit.component';
import { DeleteComponent } from './review/delete/delete.component';
import { WelcomeComponent } from './review/welcome/welcome.component';
import { ReviewlistingpageComponent } from './review/reviewlistingpage/reviewlistingpage.component';
import { FrontendComponent } from './frontend/frontend.component';


const routes: Routes = [{path : '', component : WelcomeComponent},
{path : 'review', component : ReviewlistingpageComponent},
  { path: 'review/edit/:id', component: EditComponent },
{path : 'delete', component : DeleteComponent},
{path : 'frontend',component : FrontendComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
