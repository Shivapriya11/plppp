import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Review } from '../bean/review';
const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class ReviewService {
  reviewUrl: string= 'http://localhost:4000/';
  reviewData:Review;
  review: Review[];
  private id;
  constructor(private http: HttpClient) { }
  
  public getAllReviews() {
    return this.http.get<Review[]>(this.reviewUrl+'/reviews');
  }
 
    

getReview(id:number){
return this.http.get<Review>(this.reviewUrl+'reviews/'+id);
 } 



editReview(review:Review){
return this.http.put(this.reviewUrl+'reviews/'+review.id,review);
}

deleteReview(review:Review){
    return this.http.delete<Review[]>(this.reviewUrl+'reviews/'+review.id);
   }
  }
