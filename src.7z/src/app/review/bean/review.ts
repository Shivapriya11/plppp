export class Review {
    index:number;
    id:number;
    book:String;
    rating:number;
    headline:String;
    customer:String;
    reviewOn:String;
    lastupdate:Date;
    constructor(book:String,rating:number,headline:String,reviewOn:String, lastupdate:Date){
        this.book=book;
        this.rating=rating;
        this.headline=headline;
        this.reviewOn=reviewOn;
        this.lastupdate=lastupdate;
    }
}
