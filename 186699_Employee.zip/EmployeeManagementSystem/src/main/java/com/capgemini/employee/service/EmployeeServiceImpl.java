package com.capgemini.employee.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.capgemini.employee.dao.IEmployeeRepo;
import com.capgemini.employee.dto.Employee;
import com.capgemini.employee.exception.EmployeeException;

/**
 * 
 * @author sikothap
 * ClassName: EmployeeServiceImpl
 * Description: It overrides all the required methods
 *
 */
@Service
public class EmployeeServiceImpl implements IEmployeeService{
	@Autowired
	private IEmployeeRepo employeeDao;

	@Override
	public List<Employee> updateEmployee( Employee employee) throws EmployeeException {
		/**
		 * Method to update all the orders
		 */
		int id=employee.getEmpId();
		if(employeeDao.existsById(id)) {
			employeeDao.save(employee);
			return ViewEmployeeList();
		}
		
	
		else {
			throw new EmployeeException("Cannot Update Employee with Id"+id+"doesnt exists");
		}
		
	}


	@Override
	public List<Employee> deleteEmployee(int id) throws EmployeeException {
		/**
		 * Method to delete employee
		 */
		if(employeeDao.existsById(id)) {
			employeeDao.deleteById(id);
			return ViewEmployeeList();
		}
		else {
			throw new EmployeeException("Cannot Delete.Employee with Id"+id+"doesnt exists");
		}
				
	}

	@Override
	public List<Employee> createEmployee(Employee employee) throws EmployeeException {
		 employeeDao.save(employee);
         return ViewEmployeeList();
	}

	@Override
	public Employee FindEmployee(int id) throws EmployeeException {
		/**
		 * Method to display  employee
		 */
		try {
			
			Optional<Employee> data=employeeDao.findById(id);
			if(data.isPresent()) {
				return data.get();
			}
			else {
				throw new EmployeeException("Employee with Id"+id+ "does not exists");
			}
		} catch (Exception e) {
			throw new EmployeeException(e.getMessage());
		}
	}

	
	@Override
	public List<Employee> ViewEmployeeList() throws EmployeeException {
		/**
		 * Method to display all the employees
		 */
		try {
			return employeeDao.findAll();
		} catch (Exception e) {
			throw new EmployeeException(e.getMessage());
		}
	}

	

	@Override
	public List<Employee> ViewEmployeesByDepartmentName(String deptName) throws EmployeeException {
		
		/**
		 * Method to display employee by name
		 */
		return employeeDao.ViewEmployeeByDepartmentName(deptName);
	}

	@ExceptionHandler(EmployeeException.class) 
	 public ResponseEntity<String>handleErrors(Exception ex){ 
	 return new ResponseEntity<>(ex.getMessage(),HttpStatus.NOT_FOUND);
	}
	
}
