package com.capgemini.employee.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


import com.capgemini.employee.dto.Employee;

/**
 * 
 * @author sikothap
 * ClassName: OrderRepository
 * Description: Its a Dao Repository which extends Jpa Repository and provides all the required crud methods
 *
 */

@Repository 
public interface IEmployeeRepo extends JpaRepository<Employee, Integer>{
	@Query("from Employee where deptName=:deptName")
	List<Employee>ViewEmployeeByDepartmentName(@Param("deptName") String deptName);
	
	

}
