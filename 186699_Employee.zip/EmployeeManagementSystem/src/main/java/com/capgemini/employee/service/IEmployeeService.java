package com.capgemini.employee.service;

import java.util.List;

import com.capgemini.employee.dto.Employee;
import com.capgemini.employee.exception.EmployeeException;



public interface IEmployeeService {
	List<Employee>createEmployee(Employee employee)throws EmployeeException;
	List<Employee>updateEmployee(Employee employee)throws EmployeeException;
	List<Employee>deleteEmployee(int id)throws EmployeeException;
	 List<Employee> ViewEmployeeList() throws EmployeeException; 
	Employee FindEmployee(int id)throws EmployeeException;
	List<Employee>ViewEmployeesByDepartmentName(String deptName)throws EmployeeException;
}
