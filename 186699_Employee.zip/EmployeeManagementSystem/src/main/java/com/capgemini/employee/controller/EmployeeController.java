package com.capgemini.employee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.employee.dto.Employee;
import com.capgemini.employee.exception.EmployeeException;
import com.capgemini.employee.service.IEmployeeService;

/**
 * 
 * @author sikothap
 * Date: 23-08-2019
 * ClassName: EmployeeController
 * Description: Its a controller which does all the mappings
 *
 */

@RestController
public class EmployeeController {
@Autowired
private IEmployeeService employeeService;

@GetMapping("/employees")
public List<Employee> ViewEmployeeList() throws EmployeeException{
	return employeeService.ViewEmployeeList();
	
}

@PostMapping("/employees")

public List<Employee>createEmployee(@RequestBody Employee employee)throws EmployeeException{
	return employeeService.createEmployee(employee);
}
	
	  @DeleteMapping("/employees/delete/{id}") 
	  public List<Employee> deleteEmployee(@PathVariable int id) throws EmployeeException{ 
		  return employeeService.deleteEmployee(id); 
	  }
	  
	  @PutMapping("/updateemployee") 
	  public List<Employee>
	  updateEmployee(@RequestBody Employee employee) throws EmployeeException{
	  return employeeService.updateEmployee(employee); 
	  }
	  
	  
	  
	  @GetMapping("/employees/{deptName}") 
	  public List<Employee>ViewEmployeesByDepartmentName(@PathVariable String deptName)
	  throws EmployeeException{ 
		  return  employeeService.ViewEmployeesByDepartmentName(deptName);
	  
	  }
	  @GetMapping("/getbyid") 
	  public Employee findEmployee(@RequestParam int id)
	  throws EmployeeException{ 
		  return  employeeService.FindEmployee(id);
	  
	  }
	 
}