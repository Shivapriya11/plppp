package com.capgemini.bank.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.capgemini.bank.bean.Account;
import com.capgemini.bank.bean.Customer;
import com.capgemini.bank.bean.Transaction;
import com.capgemini.bank.exception.BankException;


public class BankAccountDaoImpl implements BankAccountDao {
	EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
	EntityManager manager=factory.createEntityManager();
	@Override
	public int createAccount(Customer customer, double amount) throws BankException {
		manager.getTransaction().begin();
		Query query=manager.createNativeQuery("select accseq.nextval from dual");
		int accountNo=query.getFirstResult();
		Account account=new Account();
		account.setAccountNo(accountNo);
		account.setBalance(amount);
		manager.persist(account);
		//System.out.println(account);
		Query query1=manager.createNativeQuery("select transseq.nextval from dual");
		int transId=query1.getFirstResult();
		Transaction transaction=new Transaction();
		transaction.setTransactionNo(transId);
		transaction.setTransactionType("credit");
		long millis=System.currentTimeMillis();  
	    java.sql.Date date=new java.sql.Date(millis); 
		transaction.setTransactionDate(date);
		transaction.setAccountNo(account.getAccountNo());
		transaction.setAmount(amount);
		manager.persist(transaction);
		//System.out.println(transaction);
		Query query2=manager.createNativeQuery("select custseq.nextval from dual");
		int custId=query2.getFirstResult();
		customer.setCustomerId(custId);
		customer.setAccountNo(account.getAccountNo());
		customer.setTransactionNo(transaction.getTransactionNo());
		manager.persist(customer);
		manager.getTransaction().commit();
		return account.getAccountNo();
	}

	@Override
	public double showBalance(int accountNo) throws BankException {
		manager.getTransaction().begin();
		Account account=manager.find(Account.class, accountNo);
		manager.getTransaction().commit();
		return account.getBalance();
	}

	@Override
	public List<Transaction> deposit(int accountNo, double amount) throws BankException {
		manager.getTransaction().begin();
		Account account=manager.find(Account.class, accountNo);
		double balance=account.getBalance();
		balance+=amount;
		account.setBalance(balance);
		manager.merge(account);
		Query query=manager.createNativeQuery("select transseq.nextval from dual");
		int transId=query.getFirstResult();
		Transaction transaction=new Transaction();
		transaction.setTransactionNo(transId);
		transaction.setTransactionType("credit");
		long millis=System.currentTimeMillis();  
	    java.sql.Date date=new java.sql.Date(millis);  
		transaction.setTransactionDate(date);
		transaction.setAccountNo(accountNo);
		transaction.setAmount(amount);
		List<Transaction> transactionList=new ArrayList<>();
		transactionList.add(transaction);
		manager.persist(transaction);
		manager.getTransaction().commit();
		return transactionList;
	}

	@Override
	public List<Transaction> withdraw(int accountNo, double amount) throws BankException {
		manager.getTransaction().begin();
		Account account=manager.find(Account.class, accountNo);
		double balance=account.getBalance();
		balance-=amount;
		account.setBalance(balance);
		manager.merge(account);
		Query query=manager.createNativeQuery("select transseq.nextval from dual");
		int transId=query.getFirstResult();
		Transaction transaction=new Transaction();
		transaction.setTransactionNo(transId);
		transaction.setTransactionType("debit");
		long millis=System.currentTimeMillis();  
	    java.sql.Date date=new java.sql.Date(millis);  
		transaction.setTransactionDate(date);
		transaction.setAccountNo(accountNo);
		transaction.setAmount(amount);
		List<Transaction> transactionList=new ArrayList<>();
		transactionList.add(transaction);
		manager.persist(transaction);
		manager.getTransaction().commit();
		return transactionList;
	}

	@Override
	public List<Transaction> fundTransfer(int sourceAccount, int destinationAccount, double amount)
			throws BankException {
		manager.getTransaction().begin();
		Account source=manager.find(Account.class, sourceAccount);
		double sourceBalance=source.getBalance()-amount;
		source.setBalance(sourceBalance);
		manager.merge(source);
		Account destination=manager.find(Account.class, destinationAccount);
		double destinationBalance=destination.getBalance()+amount;
		destination.setBalance(destinationBalance);
		manager.merge(destination);
		Query query=manager.createNativeQuery("select transseq.nextval from dual");
		int transId=query.getFirstResult();
		Transaction transaction=new Transaction();
		transaction.setTransactionNo(transId);
		transaction.setTransactionType("debit");
		long millis=System.currentTimeMillis();  
	    java.sql.Date date=new java.sql.Date(millis);  
		transaction.setTransactionDate(date);
		transaction.setAccountNo(sourceAccount);
		transaction.setAmount(amount);
		List<Transaction> transactionList=new ArrayList<>();
		transactionList.add(transaction);
		manager.persist(transaction);
		
		  Query desquery=manager.createNativeQuery("select transseq.nextval from dual");
		  int destransId=desquery.getFirstResult(); 
		  Transaction destransaction=new Transaction(); 
		  destransaction.setTransactionNo(destransId);
		  destransaction.setTransactionType("credit");
		  long desmillis=System.currentTimeMillis();
		  java.sql.Date desdate=new java.sql.Date(desmillis); 
		  destransaction.setTransactionDate(desdate);
		  destransaction.setAccountNo(destinationAccount);
		  destransaction.setAmount(amount);
		  transactionList.add(destransaction);
		  manager.persist(destransaction);
		 manager.getTransaction().commit();
		return transactionList;
	}

	@Override
	public List<Transaction> PrintTransaction(int accountNo) throws BankException {
		List<Transaction> transactionList=new ArrayList<>();
		Query query=manager.createQuery("select trans from Transaction trans where accountno=:num");
		query.setParameter("num",accountNo);
		transactionList=query.getResultList();
		return transactionList;
	}
	

}
