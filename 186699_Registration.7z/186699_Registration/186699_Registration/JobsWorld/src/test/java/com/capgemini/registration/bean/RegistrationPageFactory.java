package com.capgemini.registration.bean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class RegistrationPageFactory {

	WebDriver driver;
	
	@FindBy(how = How.NAME, name = "userid")
	@CacheLookup
	WebElement userId;
	
	@FindBy(how = How.NAME, name = "passid")
	@CacheLookup
 WebElement password;
	
	@FindBy(how = How.NAME, name = "username")
	@CacheLookup
	WebElement name;
	
	@FindBy(how = How.NAME, name = "address")
	@CacheLookup
	WebElement address;
	
	@FindBy(how = How.NAME, name = "country")
	@CacheLookup
	 WebElement country;
	
	@FindBy(how = How.NAME, name = "zip")
	@CacheLookup
	 WebElement zipcode;
	
	@FindBy(how = How.NAME, name = "email")
	@CacheLookup
	 WebElement emailid;
	
	@FindBy(how = How.NAME, name = "sex")
	@CacheLookup
	WebElement sex;
	
	@FindBy(how = How.NAME, name = "en")
	@CacheLookup
	 WebElement language;
	
	@FindBy(how = How.NAME, name = "submit")
	@CacheLookup
	 WebElement submit;
	
	
	public RegistrationPageFactory(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getUserid() {
		return userId;
	}

	public void setUserid(String userId) {
		this.userId.sendKeys(userId);
	}

	public WebElement getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	public WebElement getName() {
		return name;
	}

	public void setName(String name) {
		this.name.sendKeys(name);
	}

	public WebElement getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address.sendKeys(address);
	}

	public WebElement getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country.sendKeys(country);
	}

	public WebElement getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode.sendKeys(zipcode);
	}

	public WebElement getEmailid() {
		return emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid.sendKeys(emailid);
	}

	public WebElement getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex.sendKeys(sex);
	}

	public WebElement getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language.sendKeys(language);
	}

	public WebElement getSubmit() {
		return submit;
	}

	public void setSubmit(WebElement submit) {
	   submit.click();
	}

	public void setSubmit() {
		submit.click();
		
	}


	
}
