package com.capgemini.registration.stepdefinition;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.capgemini.registration.bean.RegistrationPageFactory;


import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class RegistrationStepdefinition {
	private WebDriver driver;
    RegistrationPageFactory register;
	
	@Before
	public void setUp() {
System.setProperty("webdriver.chrome.driver","C:\\BDD699\\JobsWorld\\drivers\\chromedriver.exe");
		
		driver= new ChromeDriver();
	}
	
	@Given("^user is on 'RegistrationForm' page$")
	public void user_is_on_Registration_Form_page() throws Throwable {
		driver.get("C:\\BDD699\\JobsWorld\\target\\RegistrationForm.html");
		register= new RegistrationPageFactory(driver);
		register = PageFactory.initElements(driver, RegistrationPageFactory.class);
		driver.manage().window().maximize();
	}

	@When("^page is loaded$")
	public void page_is_loaded() throws Throwable {
	    
	}

	@Then("^check if title of the page is 'Welcome to JobsWorld$")
	public void check_if_title_of_the_page_is_Welcome_to_JobsWorld_page() throws Throwable {
		String expectedTitle = "Welcome to JobsWorld";
		String actualTitle = driver.getTitle();
		Assert.assertEquals(expectedTitle, actualTitle);
	}

	@Then("^check if there is a text 'RegistrationForm'$")
	public void check_if_there_is_a_text_Registration_Form() throws Throwable {
		boolean expectedResult = true;
		String expectedText = "RegistrationForm";
		boolean actualResult = driver.getPageSource().contains(expectedText);
		Assert.assertEquals(expectedResult, actualResult);
		driver.close();
	}

	@When("^user is trying to submit data without entering User Id$")
	public void user_is_trying_to_submit_data_without_entering_User_Id() throws Throwable {
	
		register.setUserid("");
		register.setSubmit();
	}

	@Then("^the alert box displays 'User Id should not be empty/length be between (\\d+) to (\\d+)'$")
	public void the_alert_box_displays_User_Id_should_not_be_empty_length_be_between_to(int arg1, int arg2) throws Throwable {
		Thread.sleep(2000);
		String expectedMessage="Please fill the UserId";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user is trying to submit data without entering Password$")
	public void user_is_trying_to_submit_data_without_entering_Password() throws Throwable {
		Thread.sleep(2000);
		register.setUserid("userId");
		register.setPassword("");
		register.setSubmit();
	}

	@Then("^the alert box displays 'Password should not be empty/length be between (\\d+) to (\\d+)'$")
	public void the_alert_box_displays_Password_should_not_be_empty_length_be_between_to(int arg1, int arg2) throws Throwable {
		Thread.sleep(2000);
		String expectedMessage="Please fill the Password";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close(); 
	}

	@When("^user is trying to submit data without entering Name$")
	public void user_is_trying_to_submit_data_without_entering_Name() throws Throwable {
		register.setUserid("userId");
		register.setPassword("password");
		register.setName("");
		register.setSubmit();
	}

	@Then("^the alert box displays 'Name should not be empty and must have alphabetic characters only'$")
	public void the_alert_box_displays_Name_should_not_be_empty_and_must_have_alphabetic_characters_only() throws Throwable {
		Thread.sleep(2000);
		String expectedMessage="Please fill the Name";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close(); 
	}

	@When("^user is trying to submit data without entering address$")
	public void user_is_trying_to_submit_data_without_entering_address() throws Throwable {
		register.setUserid("userId");
		register.setPassword("password");
		register.setName("Sairam");
		register.setAddress("");
		register.setSubmit();
	}

	@Then("^the alert box displays 'User address must have alphanumeric characters only'$")
	public void the_alert_box_displays_User_address_must_have_alphanumeric_characters_only() throws Throwable {
		Thread.sleep(2000);
		String expectedMessage="Please fill the user address";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close(); 
	}

	@When("^user is trying to submit data without entering Country$")
	public void user_is_trying_to_submit_data_without_entering_Country() throws Throwable {
		register.setUserid("userId");
		register.setPassword("password");
		register.setName("Sairam");
		register.setAddress("Hyderabad");
		register.setSubmit();
	}

	@Then("^the alert box displays 'Select your country from the list'$")
	public void the_alert_box_displays_Select_your_country_from_the_list() throws Throwable {
		Thread.sleep(2000);
		String expectedMessage="Please fill the country";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close(); 
	}

	@When("^user is trying to submit data without entering Zip Code$")
	public void user_is_trying_to_submit_data_without_entering_Zip_Code() throws Throwable {
		register.setUserid("userId");
		register.setPassword("password");
		register.setName("Sairam");
		register.setAddress("Hyderabad");
		register.setCountry("India");
		register.setZipcode("");
		register.setSubmit();
	}

	@Then("^the alert box displays 'ZIP Code must have numeric characters only'$")
	public void the_alert_box_displays_ZIP_Code_must_have_numeric_characters_only() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		Thread.sleep(2000);
	    String actualmessage=driver.switchTo().alert().getText();
	    String expectedmessage="ZIP code must have  numeric characters only";
	    Assert.assertEquals(actualmessage, expectedmessage);
	}
	
	@When("^user is trying to submit data without entering Email Id$")
	public void user_is_trying_to_submit_data_without_entering_Email_Id() throws Throwable {
		register.setUserid("userId");
		register.setPassword("password");
		register.setName("Sairam");
		register.setAddress("Hyderabad");
		register.setCountry("India");
		register.setZipcode("789");
		register.setEmailid("");
		register.setSubmit();
	}

	@Then("^the alert box displays 'You have entered an invalid email address!'$")
	public void the_alert_box_displays_You_have_entered_an_invalid_email_address() throws Throwable {
		String expectedMessage="Please fill the email";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close(); 
	}

	@When("^user is trying to submit data without entering Sex$")
	public void user_is_trying_to_submit_data_without_entering_Sex() throws Throwable {
		register.setUserid("userId");
		register.setPassword("password");
		register.setName("Sairam");
		register.setAddress("Hyderabad");
		register.setCountry("India");
		register.setZipcode("789");
		register.setEmailid("sairam@gmail.com");
		register.setSex("");
		register.setSubmit();
	}

	@Then("^the alert box displays 'Please Select gender upon non selection of gender'$")
	public void the_alert_box_displays_Please_Select_gender_upon_non_selection_of_gender() throws Throwable {
		Thread.sleep(2000);
		String expectedMessage="Please fill the gender";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close(); 
	}

	@When("^user is trying to submit data without entering Language$")
	public void user_is_trying_to_submit_data_without_entering_Language() throws Throwable {
		register.setUserid("userId");
		register.setPassword("password");
		register.setName("Sairam");
		register.setAddress("Hyderabad");
		register.setCountry("India");
		register.setZipcode("789");
		register.setEmailid("sairam@gmail.com");
		register.setSex("male");
		register.setLanguage("");
		register.setSubmit();
	}

	@Then("^the alert box displays 'Default language is English'$")
	public void the_alert_box_displays_Default_language_is_English() throws Throwable {
		Thread.sleep(2000);
		String expectedMessage="Please fill the language";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close(); 
	}

	@Given("^User is on 'RegistrationForm' page$")
	public void user_is_on_Registration_Form_page1() throws Throwable {
		register.setUserid("userId");
		register.setPassword("password");
		register.setName("Sairam");
		register.setAddress("Hyderabad");
		register.setCountry("India");
		register.setZipcode("789");
		register.setEmailid("sairam@gmail.com");
		register.setSex("male");
		register.setLanguage("English");
		register.setSubmit();
	}

@Then("^Click on Submit Button$")
	public void the_alert_box_displays_Click_on_a_Submit_button() throws Throwable {
	driver.get("C:\\BDD699\\JobsWorld\\target\\RegistrationForm.html");
	driver.close();
	}

}
