package com.capgemini.registration.test;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features = "C:\\BDD699\\JobsWorld\\src\\test\\resources\\features\\registration.feature", glue = { "com.capgemini.registration.stepdefinition" })
public class TestRunner {

}
